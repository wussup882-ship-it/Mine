# Stick Sword (Fabric, Minecraft Java 26.3)
Adds one item: the Stick Sword (craft with 3 sticks in a column).
Build: push to GitHub, open Actions > build, download the jar from Artifacts.
Needs Fabric Loader 0.19.5+, Fabric API for 26.3, Java 25.
